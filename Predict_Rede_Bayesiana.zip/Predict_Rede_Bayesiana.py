from sklearn import preprocessing



from sklearn.naive_bayes import GaussianNB



import numpy as np





patient=['Joao','Pedro','Maria','Jose','Ana','Leia']


fever=['Yes','No','Yes','Yes','Yes','No']


sickness=['Yes','No','Yes','No','No','No']


stains=['Small','Big','Small','Big','Small','Big']


pains=['Yes','No','No','Yes','Yes','Yes']


play=['Sick','Healthy','Healthy','Sick','Healthy','Sick']




le = preprocessing.LabelEncoder()



patient_encoded=le.fit_transform(patient)



fever_encoded=le.fit_transform(fever)


sickness_encoded=le.fit_transform(sickness)


stains_encoded=le.fit_transform(stains)


pains_encoded=le.fit_transform(pains)



label=le.fit_transform(play)



print("patient:",patient_encoded)

print("fever:",fever_encoded)

print("sickness:",sickness_encoded)

print("stains:",stains_encoded)

print("pains:",pains_encoded)

print("Play:",label)




features=np.array((patient_encoded,fever_encoded,sickness_encoded,stains_encoded,pains_encoded)).T



print(features)




model = GaussianNB()




model.fit(features,label)




predicted= model.predict([[0,2]]) 

print("Predicted Value:", predicted)

predicted= model.predict([[2,1]]) 

print("Predicted Value:", predicted)